# RubyAntiXray — jar nasil alinir

Bilgisayarina hicbir sey kurmadan, GitHub'a derletebilirsin. 5 dakika surer.

## 1. Depo olustur
github.com -> sag ustteki `+` -> **New repository**
- Ad: `RubyAntiXray`
- **Public** sec (Actions ucretsiz calissin diye)
- **Create repository**

## 2. Dosyalari yukle
Acilan sayfada **uploading an existing file** baglantisina tikla.
Bu zipten cikan `RubyAntiXray` klasorunun **icindekilerin tamamini**
(surukleyip birak) yukle:

```
.github/workflows/build.yml
pom.xml
src/main/java/net/mrwqlf/antixray/RubyAntiXray.java
src/main/resources/plugin.yml
src/main/resources/config.yml
```

Klasor yapisi korunmali. Tarayici klasor surukle-birakti destekler;
`src` ve `.github` klasorlerini oldugu gibi birak.
Asagida **Commit changes** butonuna bas.

## 3. Derlemeyi baslat
Ust menuden **Actions** sekmesine gec.
- "Build RubyAntiXray" is akisini gorursun; push ile zaten baslamis olur.
- Baslamadiysa: sol taraftan **Build RubyAntiXray** -> sagda
  **Run workflow** -> **Run workflow**.

Yesil tik gelene kadar bekle (1-2 dakika).

## 4. Jar'i indir
Tamamlanan calismaya tikla, sayfanin altindaki **Artifacts** bolumunden
`RubyAntiXray-jar` dosyasini indir. Icinden `RubyAntiXray-1.0.0.jar` cikar.

## 5. Sunucuya kur
Jar'i sunucunun `plugins/` klasorune at:

```
sunucu/
├─ server.jar
├─ server.properties
└─ plugins/
   └─ RubyAntiXray-1.0.0.jar
```

Sunucuyu yeniden baslat. `/plugins` yazinca yesil gorunmeli.
Ilk aciliste `plugins/RubyAntiXray/config.yml` kendiliginden olusur.

Panel kullaniyorsan (Aternos vb.): panelin **Plugins -> Kendi eklentini
yukle** bolumunden jar'i at.

## Surum uyumu
`pom.xml` Paper 1.21.4 API'sine bakiyor. Sunucun farkli surumdeyse
`pom.xml` icindeki `1.21.4-R0.1-SNAPSHOT` degerini kendi surumune cevir
(orn. `1.21.8-R0.1-SNAPSHOT`), sonra Actions'i tekrar calistir.

## Komutlar
| Komut | Ne yapar |
|---|---|
| `/antixray top` | En supheli 10 oyuncu |
| `/antixray check <oyuncu>` | Tek oyuncunun sayilari |
| `/antixray reset <oyuncu>` | O oyuncunun verisini sifirlar |
| `/antixray reload` | config.yml'i yeniden yukler |

Izinler: `rubyantixray.admin`, `rubyantixray.alerts`, `rubyantixray.bypass`

## Unutma
Bu eklenti blok GIZLEMEZ, sadece tespit eder. Asil korumayi Paper'in
dahili anti-xray'i saglar — `config/paper-world-defaults.yml` icindeki
`anticheat: anti-xray:` bolumu. Ikisini birlikte kullan.
