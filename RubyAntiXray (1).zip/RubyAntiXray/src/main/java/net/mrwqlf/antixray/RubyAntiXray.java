package net.mrwqlf.antixray;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.stream.Collectors;

/**
 * RubyAntiXray — davranis tabanli xray TESPITI.
 *
 * Bu eklenti blok GIZLEMEZ. Gizleme isini Paper'in dahili anti-xray'i
 * cok daha verimli yapar (paper-world-defaults.yml). Bu eklenti onun
 * ustune, "gizleme kapali olsa bile kim supheli davraniyor" sorusunu
 * cevaplar ve yoneticilere bildirir.
 *
 * Olctugu seyler:
 *  1) Degerli maden / kirilan toplam tas orani
 *  2) Elmas + ancient debris orani (nadir maden yogunlugu)
 *  3) "Dogrudan yonelme": bir madeni kirmadan onceki son birkac kazma
 *     hareketinin o madene dogru olup olmadigi. Normal kazi duz gider;
 *     xray kullanan oyuncu madene dogru sapar.
 */
public final class RubyAntiXray extends JavaPlugin implements Listener {

    private final Map<UUID, Stats> stats = new HashMap<>();
    private final Map<UUID, Long> lastAlert = new HashMap<>();

    private int minOres;
    private double oreRatio, rareRatio, beelineRatio;
    private long alertCooldownMs;
    private boolean consoleAlerts;
    private final Map<Material, Double> weights = new EnumMap<>(Material.class);

    // ---- kirilan taslar (payda) ----
    private static final EnumSet<Material> STONE = EnumSet.of(
            Material.STONE, Material.DEEPSLATE, Material.ANDESITE, Material.DIORITE,
            Material.GRANITE, Material.TUFF, Material.NETHERRACK, Material.BASALT,
            Material.BLACKSTONE, Material.DIRT, Material.GRAVEL);

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("RubyAntiXray aktif. Tespit modu: davranis analizi.");
    }

    private void loadSettings() {
        reloadConfig();
        minOres = getConfig().getInt("min-ores", 25);
        oreRatio = getConfig().getDouble("thresholds.ore-ratio", 0.055);
        rareRatio = getConfig().getDouble("thresholds.rare-ratio", 0.014);
        beelineRatio = getConfig().getDouble("thresholds.beeline-ratio", 0.45);
        alertCooldownMs = getConfig().getLong("alert.cooldown-seconds", 120) * 1000L;
        consoleAlerts = getConfig().getBoolean("alert.console", true);

        weights.clear();
        var sec = getConfig().getConfigurationSection("weights");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                Material m = Material.matchMaterial(key);
                if (m != null) weights.put(m, sec.getDouble(key));
                else getLogger().warning("Bilinmeyen blok: " + key);
            }
        }
    }

    // =================================================================
    // Olay
    // =================================================================
    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (p.hasPermission("rubyantixray.bypass")) return;
        if (p.getGameMode() != org.bukkit.GameMode.SURVIVAL) return;

        Material type = e.getBlock().getType();
        Stats s = stats.computeIfAbsent(p.getUniqueId(), k -> new Stats());

        if (STONE.contains(type)) {
            s.stone++;
            s.pushPath(e.getBlock().getLocation().toVector());
            return;
        }

        Double w = weights.get(type);
        if (w == null) return;

        s.ores++;
        s.weighted += w;
        if (type == Material.DIAMOND_ORE || type == Material.DEEPSLATE_DIAMOND_ORE
                || type == Material.ANCIENT_DEBRIS) {
            s.rare++;
        }
        // son kazi hareketleri bu madene dogru muydu?
        if (s.wasBeeline(e.getBlock().getLocation().toVector())) s.beeline++;
        s.pushPath(e.getBlock().getLocation().toVector());

        evaluate(p, s);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        // istatistik kalir; sadece yol gecmisi temizlenir
        Stats s = stats.get(e.getPlayer().getUniqueId());
        if (s != null) s.path.clear();
    }

    // =================================================================
    // Degerlendirme
    // =================================================================
    private void evaluate(Player p, Stats s) {
        if (s.ores < minOres) return;

        int total = s.stone + s.ores;
        if (total < 50) return;

        double ratio = (double) s.ores / total;
        double rare = (double) s.rare / total;
        double bee = (double) s.beeline / Math.max(1, s.ores);

        List<String> hits = new ArrayList<>();
        if (ratio > oreRatio) hits.add(String.format("maden orani %%%.2f", ratio * 100));
        if (rare > rareRatio) hits.add(String.format("nadir maden orani %%%.2f", rare * 100));
        if (bee > beelineRatio) hits.add(String.format("dogrudan yonelme %%%.0f", bee * 100));

        if (hits.size() < 2) return;   // tek olcut yeterli degil, en az iki isaret

        long now = System.currentTimeMillis();
        Long last = lastAlert.get(p.getUniqueId());
        if (last != null && now - last < alertCooldownMs) return;
        lastAlert.put(p.getUniqueId(), now);

        String msg = ChatColor.DARK_RED + "[AntiXray] " + ChatColor.RED + p.getName()
                + ChatColor.GRAY + " supheli: " + String.join(", ", hits)
                + ChatColor.DARK_GRAY + "  (" + s.ores + " maden / " + total + " blok, "
                + String.format("agirlik %.1f", s.weighted) + ")";

        if (consoleAlerts) getLogger().warning(ChatColor.stripColor(msg));
        for (Player admin : Bukkit.getOnlinePlayers()) {
            if (admin.hasPermission("rubyantixray.alerts")) admin.sendMessage(msg);
        }
    }

    // =================================================================
    // Komut
    // =================================================================
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ChatColor.GRAY + "/antixray <top|check <oyuncu>|reset <oyuncu>|reload>");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                loadSettings();
                sender.sendMessage(ChatColor.GREEN + "AntiXray ayarlari yeniden yuklendi.");
            }
            case "top" -> {
                var list = stats.entrySet().stream()
                        .filter(en -> en.getValue().ores >= minOres)
                        .sorted((a, b) -> Double.compare(b.getValue().score(), a.getValue().score()))
                        .limit(10).collect(Collectors.toList());
                if (list.isEmpty()) {
                    sender.sendMessage(ChatColor.GRAY + "Yeterli veri toplanmis oyuncu yok.");
                    return true;
                }
                sender.sendMessage(ChatColor.DARK_RED + "--- AntiXray siralamasi ---");
                for (var en : list) {
                    var op = Bukkit.getOfflinePlayer(en.getKey());
                    sender.sendMessage(ChatColor.GRAY + " " + op.getName() + ChatColor.WHITE
                            + String.format("  skor %.2f", en.getValue().score())
                            + ChatColor.DARK_GRAY + "  " + en.getValue().summary());
                }
            }
            case "check" -> {
                if (args.length < 2) {
                    sender.sendMessage(ChatColor.RED + "Oyuncu adi yaz.");
                    return true;
                }
                var op = Bukkit.getOfflinePlayer(args[1]);
                Stats s = stats.get(op.getUniqueId());
                if (s == null) {
                    sender.sendMessage(ChatColor.GRAY + "Bu oyuncu icin veri yok.");
                    return true;
                }
                sender.sendMessage(ChatColor.DARK_RED + "[AntiXray] " + ChatColor.WHITE
                        + args[1] + ChatColor.GRAY + "  " + s.summary());
            }
            case "reset" -> {
                if (args.length < 2) {
                    sender.sendMessage(ChatColor.RED + "Oyuncu adi yaz.");
                    return true;
                }
                var op = Bukkit.getOfflinePlayer(args[1]);
                stats.remove(op.getUniqueId());
                lastAlert.remove(op.getUniqueId());
                sender.sendMessage(ChatColor.GREEN + args[1] + " verisi sifirlandi.");
            }
            default -> sender.sendMessage(ChatColor.GRAY
                    + "/antixray <top|check <oyuncu>|reset <oyuncu>|reload>");
        }
        return true;
    }

    // =================================================================
    private static final class Stats {
        int stone, ores, rare, beeline;
        double weighted;
        final Deque<org.bukkit.util.Vector> path = new ArrayDeque<>();

        void pushPath(org.bukkit.util.Vector v) {
            path.addLast(v);
            if (path.size() > 6) path.removeFirst();
        }

        /** Son kazi hareketleri madene dogru mu saptirmis? */
        boolean wasBeeline(org.bukkit.util.Vector ore) {
            if (path.size() < 4) return false;
            var it = path.iterator();
            var first = it.next();
            org.bukkit.util.Vector last = first;
            while (it.hasNext()) last = it.next();

            var digDir = last.clone().subtract(first);
            if (digDir.lengthSquared() < 1) return false;
            var oreDir = ore.clone().subtract(last);
            if (oreDir.lengthSquared() < 1 || oreDir.lengthSquared() > 100) return false;

            double cos = digDir.normalize().dot(oreDir.normalize());
            // kazi yonu ile madene giden yon neredeyse ayni -> dogrudan yonelme
            return cos > 0.87;
        }

        double score() {
            int total = stone + ores;
            if (total == 0) return 0;
            double r = (double) ores / total;
            double rr = (double) rare / total;
            double bb = (double) beeline / Math.max(1, ores);
            return r * 40 + rr * 120 + bb * 10 + weighted / 100.0;
        }

        String summary() {
            int total = stone + ores;
            return String.format("maden %d, nadir %d, tas %d, yonelme %d  (oran %%%.2f)",
                    ores, rare, stone, beeline, total == 0 ? 0 : (double) ores / total * 100);
        }
    }
}
