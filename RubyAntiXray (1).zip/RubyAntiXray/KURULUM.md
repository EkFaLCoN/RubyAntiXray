# RubyAntiXray

Iki katmanli anti-xray. Ikisini birlikte kullan.

## 1. Katman — Paper'in dahili anti-xray (asil koruma)

Bloklari **gizleyen** kisim budur ve sunucuya neredeyse hic yuk bindirmez.
Eklentiyle yapilmaz, Paper ayarindan acilir.

`config/paper-world-defaults.yml` (eski surumlerde `paper.yml`):

```yaml
anticheat:
  anti-xray:
    enabled: true
    engine-mode: 2
    max-block-height: 64
    update-radius: 2
    lava-obscures: false
    use-permission: false
    hidden-blocks:
      - copper_ore
      - deepslate_copper_ore
      - gold_ore
      - deepslate_gold_ore
      - iron_ore
      - deepslate_iron_ore
      - coal_ore
      - deepslate_coal_ore
      - lapis_ore
      - deepslate_lapis_ore
      - diamond_ore
      - deepslate_diamond_ore
      - redstone_ore
      - deepslate_redstone_ore
      - emerald_ore
      - deepslate_emerald_ore   # <- Ruby Ore
      - ancient_debris
    replacement-blocks:
      - stone
      - deepslate
      - netherrack
```

- `engine-mode: 1` — madenleri tasla degistirir, hafif.
- `engine-mode: 2` — her yere sahte maden serpistirir. Xray'i ise yaramaz
  hale getirir, biraz daha fazla kaynak yer. **Tavsiye edilen bu.**
- `max-block-height: 64` bu yukseklige kadar calisir; deepslate seviyesi
  icin yeterli, dusurursen daha az kaynak yer.
- **Nether icin** `replacement-blocks` listesinde `netherrack` olmali,
  yoksa Nether'de garip gorunur.

Not: Ruby Ore aslinda `deepslate_emerald_ore` oldugu icin listede o isimle
geciyor. Resourcepack onu ruby gibi gosteriyor ama sunucu tarafinda
zumrut cevheridir.

## 2. Katman — Bu eklenti (tespit)

Blok gizlemez. "Gizleme calissa bile kim supheli davraniyor" sorusunu
cevaplar; oyuncularin kazi davranisini olcer ve yoneticilere bildirir.

Uc olcut:
1. **Maden orani** — kirilan tasa gore degerli maden orani
2. **Nadir maden orani** — elmas + ancient debris yogunlugu
3. **Dogrudan yonelme** — kazi yonu birden madene sapiyor mu?
   Normal kazi duz gider; xray kullanan madene dogru kivrilir.

Uyari icin **en az iki olcutun** birden asilmasi gerekir. Tek basina
"sansli oyuncu" damgalanmaz.

### Komutlar
| Komut | Ne yapar |
|---|---|
| `/antixray top` | En supheli 10 oyuncu |
| `/antixray check <oyuncu>` | Tek oyuncunun sayilari |
| `/antixray reset <oyuncu>` | O oyuncunun verisini sifirlar |
| `/antixray reload` | config.yml'i yeniden yukler |

### Izinler
| Izin | Varsayilan |
|---|---|
| `rubyantixray.admin` | op — komutlar |
| `rubyantixray.alerts` | op — uyari mesajlarini alir |
| `rubyantixray.bypass` | false — hic izlenmez |

### Ayarlar
`config.yml` icindeki `thresholds` degerleri esikleri belirler.
Cok fazla yanlis alarm alirsan `ore-ratio` ve `rare-ratio` degerlerini
yukselt. Hic alarm gelmiyorsa dusur. `weights` altinda hangi madenin
ne kadar supheli sayilacagini ayarlarsin.

## Derleme

Java 21 ve Maven gerekiyor:

```
mvn clean package
```

Cikan dosya: `target/RubyAntiXray-1.0.0.jar` -> sunucunun `plugins/`
klasorune at, sunucuyu yeniden baslat.

`pom.xml` Paper 1.21.4 API'sine bakiyor. Sunucun farkli bir surumdeyse
`paper-api` surumunu ona gore degistir.

## Onemli

Eklenti tek basina xray'i **engellemez**, sadece tespit eder. Asil
korumayi 1. katman saglar. Ikisini birlikte kullan.
